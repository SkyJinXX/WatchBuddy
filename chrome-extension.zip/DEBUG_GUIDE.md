# YouTube语音助手 - 调试指南

## 🐛 CSP错误已修复

**问题:** Chrome扩展的CSP（内容安全策略）禁止内联事件处理器
**解决方案:** 已将所有 `onclick="..."` 改为JavaScript事件监听器

### 修复内容
- ✅ 移除了popup.html中所有内联事件处理器
- ✅ 在popup.js中添加了事件监听器绑定
- ✅ 修复了选择器错误
- ✅ 确保事件绑定在DOM加载后执行

## 🧪 测试方法

### 方法1: 直接测试扩展（推荐）
1. 打开Chrome浏览器
2. 进入 `chrome://extensions/`
3. 开启"开发者模式"
4. 点击"加载已解压的扩展程序"
5. 选择 `chrome-extension` 文件夹
6. 打开YouTube视频页面测试

### 方法2: 本地服务器测试
```bash
# 进入chrome-extension目录
cd chrome-extension

# 启动测试服务器
python start-test-server.py

# 浏览器会自动打开测试页面
# 或手动访问: http://localhost:8080/test-popup.html
```

## 🔍 调试检查清单

### 1. 检查控制台错误
- 打开Chrome开发者工具 (F12)
- 查看Console标签页
- 确认没有CSP错误

### 2. 验证功能
- [ ] API密钥输入框正常工作
- [ ] 密码显示/隐藏按钮可点击
- [ ] 保存配置按钮响应点击
- [ ] 测试API连接功能正常
- [ ] 使用说明弹窗显示

### 3. 检查权限
```javascript
// 在popup.js中添加调试代码
console.log('Chrome API available:', !!window.chrome);
console.log('Storage API available:', !!window.chrome?.storage);
```

## 🚨 常见问题解决

### 问题1: 按钮点击无响应
**原因:** 事件监听器未正确绑定
**解决:** 检查bindEventListeners()函数是否被调用

### 问题2: API密钥保存失败
**原因:** Chrome storage权限问题
**解决:** 确认manifest.json中有"storage"权限

### 问题3: 扩展图标不显示
**原因:** 图标文件缺失
**解决:** 使用icons/create_icons.html生成图标

## 📝 调试日志

如果需要详细调试，在popup.js开头添加：
```javascript
// 开启调试模式
const DEBUG = true;
const log = DEBUG ? console.log : () => {};

// 使用方式
log('调试信息:', data);
```

## 🔧 重新加载扩展

修改代码后需要重新加载扩展：
1. 进入 `chrome://extensions/`
2. 找到"YouTube Voice Assistant"
3. 点击刷新按钮 🔄
4. 重新测试功能

## ✅ 验证修复

CSP错误应该已经完全解决，你现在应该能够：
- 正常点击所有按钮
- 保存API密钥
- 查看使用统计
- 测试API连接

如果仍有问题，请检查浏览器控制台的具体错误信息。 