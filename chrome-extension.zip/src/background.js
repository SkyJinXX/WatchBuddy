/**
 * YouTube语音助手 - Background Service Worker
 * 处理扩展的后台逻辑和消息传递
 */

// 扩展安装时的初始化
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        console.log('YouTube语音助手已安装');
        
        // 设置默认配置
        chrome.storage.sync.set({
            version: '1.0.0',
            firstInstall: Date.now()
        });
        
        // 初始化使用统计
        chrome.storage.local.set({
            usage_stats: {
                total: 0,
                today: 0,
                lastDate: new Date().toDateString()
            }
        });
        
        // 打开欢迎页面
        chrome.tabs.create({
            url: chrome.runtime.getURL('welcome.html')
        });
    } else if (details.reason === 'update') {
        console.log('YouTube语音助手已更新');
    }
});

// 监听来自content script和popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.action) {
        case 'update_usage_stats':
            updateUsageStats();
            break;
            
        case 'get_api_key':
            getApiKey(sendResponse);
            return true; // 异步响应
            
        case 'log_error':
            console.error('Content Script Error:', request.error);
            break;
            
        case 'check_permissions':
            checkPermissions(sendResponse);
            return true; // 异步响应
            
        case 'fetch_subtitles':
            fetchSubtitles(request.url, request.headers, sendResponse);
            return true; // 异步响应
            
        case 'download_subtitle_content':
            downloadSubtitleContent(request.url, sendResponse);
            return true; // 异步响应
            
        default:
            console.log('未知消息类型:', request.action);
    }
});

/**
 * 更新使用统计
 */
async function updateUsageStats() {
    try {
        const result = await chrome.storage.local.get(['usage_stats']);
        const stats = result.usage_stats || { total: 0, today: 0, lastDate: null };
        
        // 检查是否是新的一天
        const today = new Date().toDateString();
        if (stats.lastDate !== today) {
            stats.today = 0;
            stats.lastDate = today;
        }
        
        // 增加计数
        stats.total += 1;
        stats.today += 1;
        
        // 保存统计
        await chrome.storage.local.set({ usage_stats: stats });
        
        console.log('使用统计已更新:', stats);
        
    } catch (error) {
        console.error('更新使用统计失败:', error);
    }
}

/**
 * 获取API密钥
 */
async function getApiKey(sendResponse) {
    try {
        const result = await chrome.storage.sync.get(['openai_api_key']);
        sendResponse({ 
            success: true, 
            apiKey: result.openai_api_key 
        });
    } catch (error) {
        console.error('获取API密钥失败:', error);
        sendResponse({ 
            success: false, 
            error: error.message 
        });
    }
}

/**
 * 检查权限
 */
async function checkPermissions(sendResponse) {
    try {
        // 检查必要的权限
        const permissions = await chrome.permissions.getAll();
        
        const requiredHosts = [
            'https://www.youtube.com/*',
            'https://api.openai.com/*'
        ];
        
        const hasAllPermissions = requiredHosts.every(host => 
            permissions.origins.includes(host)
        );
        
        sendResponse({
            success: true,
            hasAllPermissions: hasAllPermissions,
            permissions: permissions
        });
        
    } catch (error) {
        console.error('检查权限失败:', error);
        sendResponse({
            success: false,
            error: error.message
        });
    }
}

// 监听标签页更新，用于检测YouTube页面
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // 只处理完成加载的YouTube视频页面
    if (changeInfo.status === 'complete' && 
        tab.url && 
        tab.url.includes('youtube.com/watch')) {
        
        console.log('检测到YouTube视频页面:', tab.url);
        
        // 可以在这里发送消息给content script
        chrome.tabs.sendMessage(tabId, {
            action: 'page_ready',
            url: tab.url
        }).catch(() => {
            // 忽略错误，可能content script还未注入
        });
    }
});

// 监听扩展按钮点击
chrome.action.onClicked.addListener((tab) => {
    // 如果是YouTube视频页面，可以直接激活语音助手
    if (tab.url && tab.url.includes('youtube.com/watch')) {
        chrome.tabs.sendMessage(tab.id, {
            action: 'activate_voice_assistant'
        }).catch(() => {
            console.log('无法发送消息到content script');
        });
    }
});

// 清理过期的存储数据
chrome.runtime.onStartup.addListener(() => {
    cleanupStorage();
});

/**
 * 清理过期的存储数据
 */
async function cleanupStorage() {
    try {
        // 清理7天前的对话历史
        const result = await chrome.storage.local.get(['conversation_history']);
        if (result.conversation_history) {
            const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
            const filteredHistory = result.conversation_history.filter(
                item => item.timestamp > sevenDaysAgo
            );
            
            if (filteredHistory.length !== result.conversation_history.length) {
                await chrome.storage.local.set({
                    conversation_history: filteredHistory
                });
                console.log('已清理过期的对话历史');
            }
        }
        
    } catch (error) {
        console.error('清理存储失败:', error);
    }
}

// 错误处理
chrome.runtime.onSuspend.addListener(() => {
    console.log('Service Worker即将挂起');
});

// 监听存储变化
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.openai_api_key) {
        console.log('API密钥已更新');
        // 通知所有YouTube标签页重新初始化
        notifyAllYouTubeTabs();
    }
});

/**
 * 通知所有YouTube标签页
 */
async function notifyAllYouTubeTabs() {
    try {
        const tabs = await chrome.tabs.query({
            url: ['*://www.youtube.com/watch*', '*://youtube.com/watch*']
        });
        
        tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, {
                action: 'api_key_updated'
            }).catch(() => {
                // 忽略错误
            });
        });
        
    } catch (error) {
        console.error('通知标签页失败:', error);
    }
}

// 定期清理和维护
setInterval(() => {
    cleanupStorage();
}, 60 * 60 * 1000); // 每小时清理一次

/**
 * 代理字幕API请求，绕过CORS限制
 */
async function fetchSubtitles(url, headers, sendResponse) {
    try {
        console.log('Background: 发起字幕API请求:', url);
        
        const response = await fetch(url, {
            method: 'GET',
            headers: headers || {
                "authority": "get-info.downsub.com",
                "accept": "application/json, text/plain, */*",
                "accept-language": "id-ID,id;q=0.9",
                "origin": "https://downsub.com",
                "referer": "https://downsub.com/",
                "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
        });

        if (!response.ok) {
            throw new Error(`API request failed: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        
        sendResponse({ 
            success: true, 
            data: data 
        });
        
        console.log('Background: 字幕API请求成功');
        
    } catch (error) {
        console.error('Background: 字幕API请求失败:', error);
        sendResponse({ 
            success: false, 
            error: error.message 
        });
    }
}

/**
 * 代理字幕内容下载请求
 */
async function downloadSubtitleContent(url, sendResponse) {
    try {
        console.log('Background: 下载字幕内容:', url);
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`Download failed: ${response.status} ${response.statusText}`);
        }
        
        const content = await response.text();
        
        sendResponse({ 
            success: true, 
            content: content 
        });
        
        console.log('Background: 字幕内容下载成功');
        
    } catch (error) {
        console.error('Background: 字幕内容下载失败:', error);
        sendResponse({ 
            success: false, 
            error: error.message 
        });
    }
}

console.log('YouTube语音助手 Background Service Worker 已启动'); 