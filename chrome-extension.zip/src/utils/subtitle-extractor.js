/**
 * YouTube字幕提取器
 * 基于reference-get-subtitle.js的核心功能
 */
class SubtitleExtractor {
    constructor() {
        this.SECRET_KEY = "zthxw34cdp6wfyxmpad38v52t3hsz6c5";
        this.API = "https://get-info.downsub.com/";
        this.CryptoJS = window.CryptoJS;
    }

    /**
     * 格式化JSON处理器
     */
    get formatJson() {
        return {
            stringify: (crp) => {
                let result = {
                    ct: crp.ciphertext.toString(this.CryptoJS.enc.Base64)
                };
                if (crp.iv) {
                    result.iv = crp.iv.toString();
                }
                if (crp.salt) {
                    result.s = crp.salt.toString();
                }
                return JSON.stringify(result);
            },
            parse: (output) => {
                let parse = JSON.parse(output);
                let result = this.CryptoJS.lib.CipherParams.create({
                    ciphertext: this.CryptoJS.enc.Base64.parse(parse.ct)
                });
                if (parse.iv) {
                    result.iv = this.CryptoJS.enc.Hex.parse(parse.iv);
                }
                if (parse.s) {
                    result.salt = this.CryptoJS.enc.Hex.parse(parse.s);
                }
                return result;
            }
        };
    }

    /**
     * Base64编码转换
     */
    _toBase64(payload) {
        let vBtoa = btoa(payload);
        vBtoa = vBtoa.replace("+", "-");
        vBtoa = vBtoa.replace("/", "_");
        vBtoa = vBtoa.replace("=", "");
        return vBtoa;
    }

    /**
     * Base64解码转换
     */
    _toBinary(base64) {
        let data = base64.replace("-", "+");
        data = data.replace("_", "/");
        const mod4 = data.length % 4;
        if (mod4) {
            data += "====".substring(mod4);
        }
        return atob(data);
    }

    /**
     * 加密数据
     */
    _encode(payload, options) {
        if (!payload) {
            return false;
        }

        let result = this.CryptoJS.AES.encrypt(JSON.stringify(payload), options || this.SECRET_KEY, {
            format: this.formatJson
        }).toString();
        return this._toBase64(result).trim();
    }

    /**
     * 解密数据
     */
    _decode(payload, options) {
        if (!payload) {
            return false;
        }

        let result = this.CryptoJS.AES.decrypt(this._toBinary(payload), options || this.SECRET_KEY, {
            format: this.formatJson
        }).toString(this.CryptoJS.enc.Utf8);
        return result.trim();
    }

    /**
     * 生成请求数据
     */
    _generateData(videoId) {
        const url = `https://www.youtube.com/watch?v=${videoId}`;
        let id = videoId;
        
        return {
            state: 99,
            url: url,
            urlEncrypt: this._encode(url),
            source: 0,
            id: this._encode(id),
            playlistId: null
        };
    }

    /**
     * 解码字幕数组
     */
    _decodeArray(result) {
        let subtitles = [], subtitlesAutoTrans = [];

        if (result?.subtitles && result?.subtitles.length) {
            result.subtitles.forEach((v, i) => {
                let ff = {...v};
                ff.url = this._decode(ff.url).replace(/^"|"$/gi, "");
                ff.enc_url = result.subtitles[i].url;
                subtitles.push(ff);
            });
        }
        
        if (result?.subtitlesAutoTrans && result?.subtitlesAutoTrans.length) {
            result.subtitlesAutoTrans.forEach((v, i) => {
                let ff = {...v};
                ff.url = this._decode(ff.url).replace(/^"|"$/gi, "");
                ff.enc_url = result.subtitlesAutoTrans[i].url;
                subtitlesAutoTrans.push(ff);
            });
        }

        return Object.assign(result, {subtitles}, {subtitlesAutoTrans});
    }

    /**
     * 获取视频ID
     */
    getVideoId() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('v');
    }

    /**
     * 获取字幕信息
     */
    async getSubtitles(videoId) {
        if (!videoId) {
            videoId = this.getVideoId();
        }

        if (!videoId) {
            throw new Error('Video ID not found');
        }

        try {
            const data = this._generateData(videoId);
            const url = `${this.API}${data.id}`;
            
            // 通过background script发起请求，绕过CORS限制
            const response = await new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({
                    action: 'fetch_subtitles',
                    url: url,
                    headers: {
                        "authority": "get-info.downsub.com",
                        "accept": "application/json, text/plain, */*",
                        "accept-language": "id-ID,id;q=0.9",
                        "origin": "https://downsub.com",
                        "referer": "https://downsub.com/",
                        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                    }
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else if (response.success) {
                        resolve(response.data);
                    } else {
                        reject(new Error(response.error || 'API request failed'));
                    }
                });
            });

            return this._decodeArray(response);

        } catch (error) {
            console.error('Error fetching subtitles:', error);
            throw error;
        }
    }

    /**
     * 下载字幕内容
     */
    async downloadSubtitleContent(subtitleUrl) {
        try {
            // 通过background script下载字幕内容
            const response = await new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({
                    action: 'download_subtitle_content',
                    url: subtitleUrl
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else if (response.success) {
                        resolve(response.content);
                    } else {
                        reject(new Error(response.error || 'Download failed'));
                    }
                });
            });

            return response;
        } catch (error) {
            console.error('Error downloading subtitle:', error);
            throw error;
        }
    }

    /**
     * 解析SRT字幕为时间戳数组
     */
    parseSRTToTimestamps(srtContent) {
        const subtitles = [];
        const blocks = srtContent.split(/\n\s*\n/);
        
        for (const block of blocks) {
            const lines = block.trim().split('\n');
            if (lines.length >= 3) {
                const timeMatch = lines[1].match(/(\d{2}):(\d{2}):(\d{2}),(\d{3}) --> (\d{2}):(\d{2}):(\d{2}),(\d{3})/);
                if (timeMatch) {
                    const startTime = this._timeToSeconds(timeMatch[1], timeMatch[2], timeMatch[3], timeMatch[4]);
                    const endTime = this._timeToSeconds(timeMatch[5], timeMatch[6], timeMatch[7], timeMatch[8]);
                    const text = lines.slice(2).join(' ').replace(/<[^>]*>/g, '').trim();
                    
                    subtitles.push({
                        start: startTime,
                        end: endTime,
                        text: text
                    });
                }
            }
        }
        
        return subtitles;
    }

    /**
     * 时间转换为秒
     */
    _timeToSeconds(hours, minutes, seconds, milliseconds) {
        return parseInt(hours) * 3600 + parseInt(minutes) * 60 + parseInt(seconds) + parseInt(milliseconds) / 1000;
    }

    /**
     * 根据时间戳获取相关字幕
     */
    getRelevantSubtitles(subtitles, currentTime, contextRange = 30) {
        const relevant = subtitles.filter(sub => 
            sub.start >= currentTime - contextRange && sub.start <= currentTime + contextRange
        );
        
        return relevant.map(sub => sub.text).join(' ');
    }

    /**
     * 获取完整字幕文本
     */
    getFullTranscript(subtitles) {
        return subtitles.map(sub => sub.text).join(' ');
    }
}

// 导出为全局变量
window.SubtitleExtractor = SubtitleExtractor; 