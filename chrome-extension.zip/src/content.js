/**
 * YouTube语音助手 - Content Script
 * 在YouTube视频页面注入语音助手功能
 */

class YouTubeVoiceAssistant {
    constructor() {
        this.subtitleExtractor = new SubtitleExtractor();
        this.aiAssistant = null;
        this.currentVideoId = null;
        this.subtitlesData = null;
        this.isProcessing = false;
        this.conversationHistory = [];
        this.floatingButton = null;
        this.statusDisplay = null;
        
        this.init();
    }

    async init() {
        // 等待页面加载完成
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setup());
        } else {
            this.setup();
        }

        // 监听页面导航
        this.observeNavigation();
        
        // 监听来自background的消息
        this.setupMessageListener();
    }

    /**
     * 设置消息监听器
     */
    setupMessageListener() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            switch (request.action) {
                case 'reload_assistant':
                    this.reloadAssistant();
                    break;
                case 'activate_voice_assistant':
                    this.handleVoiceQuery();
                    break;
                case 'api_key_updated':
                    this.reloadAssistant();
                    break;
                case 'page_ready':
                    this.setup();
                    break;
            }
        });
    }

    /**
     * 重新加载助手
     */
    async reloadAssistant() {
        this.cleanup();
        await this.setup();
    }

    async setup() {
        // 检查是否是视频页面
        if (!this.isVideoPage()) {
            return;
        }

        // 获取API密钥
        const apiKey = await this.getApiKey();
        if (!apiKey) {
            console.warn('YouTube Voice Assistant: 未配置OpenAI API密钥');
            return;
        }

        this.aiAssistant = new OpenAIVoiceAssistant(apiKey);

        // 创建浮动按钮
        this.createFloatingButton();

        // 监听视频变化
        this.observeVideoChanges();

        // 预加载字幕
        this.preloadSubtitles();
    }

    isVideoPage() {
        return window.location.pathname === '/watch' && window.location.search.includes('v=');
    }

    async getApiKey() {
        return new Promise((resolve) => {
            chrome.storage.sync.get(['openai_api_key'], (result) => {
                resolve(result.openai_api_key);
            });
        });
    }

    createFloatingButton() {
        // 移除已存在的按钮
        if (this.floatingButton) {
            this.floatingButton.remove();
        }

        // 创建浮动容器
        const container = document.createElement('div');
        container.className = 'yva-floating-container';
        container.innerHTML = `
            <div class="yva-status-display" id="yva-status" style="display: none;">
                <span class="yva-status-text">准备就绪</span>
            </div>
            <button class="yva-floating-button" id="yva-voice-btn" title="语音助手 (点击提问)">
                <svg class="yva-mic-icon" viewBox="0 0 24 24">
                    <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/>
                    <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/>
                </svg>
                <div class="yva-loading-spinner" style="display: none;">
                    <div class="yva-spinner"></div>
                </div>
            </button>
        `;

        // 添加到页面
        document.body.appendChild(container);
        
        this.floatingButton = container.querySelector('#yva-voice-btn');
        this.statusDisplay = container.querySelector('#yva-status');
        
        // 绑定点击事件
        this.floatingButton.addEventListener('click', () => this.handleVoiceQuery());
        
        // 悬停事件
        this.floatingButton.addEventListener('mouseenter', () => this.showStatus());
        this.floatingButton.addEventListener('mouseleave', () => this.hideStatus());
    }

    showStatus() {
        if (this.statusDisplay) {
            this.statusDisplay.style.display = 'block';
        }
    }

    hideStatus() {
        if (this.statusDisplay && !this.isProcessing) {
            this.statusDisplay.style.display = 'none';
        }
    }

    updateStatus(message, type = 'info') {
        if (!this.statusDisplay) return;

        const statusText = this.statusDisplay.querySelector('.yva-status-text');
        const micIcon = this.floatingButton.querySelector('.yva-mic-icon');
        const spinner = this.floatingButton.querySelector('.yva-loading-spinner');

        statusText.textContent = message;
        this.statusDisplay.className = `yva-status-display ${type}`;
        this.statusDisplay.style.display = 'block';

        // 更新按钮状态
        if (type === 'processing' || type === 'recording') {
            micIcon.style.display = 'none';
            spinner.style.display = 'block';
            this.floatingButton.disabled = true;
        } else {
            micIcon.style.display = 'block';
            spinner.style.display = 'none';
            this.floatingButton.disabled = false;
        }

        // 自动隐藏成功状态
        if (type === 'success') {
            setTimeout(() => {
                this.hideStatus();
            }, 2000);
        }
    }

    async handleVoiceQuery() {
        if (this.isProcessing) {
            return;
        }

        try {
            this.isProcessing = true;

            // 获取当前视频上下文
            const context = await this.getVideoContext();
            
            if (!context) {
                this.updateStatus('无法获取视频信息', 'error');
                return;
            }

            // 开始语音处理
            const result = await this.aiAssistant.processVoiceQuery(
                context, 
                (message, type) => this.updateStatus(message, type)
            );

            // 记录对话历史
            this.conversationHistory.push({
                timestamp: Date.now(),
                videoTime: context.currentTime,
                question: result.userQuestion,
                answer: result.aiResponse
            });

            // 更新使用统计
            this.updateUsageStats();

            console.log('对话完成:', result);

        } catch (error) {
            console.error('语音查询失败:', error);
            this.updateStatus('处理失败: ' + error.message, 'error');
            
            // 发送错误日志到background
            chrome.runtime.sendMessage({
                action: 'log_error',
                error: error.message,
                context: 'voice_query'
            });
        } finally {
            this.isProcessing = false;
            setTimeout(() => {
                if (!this.isProcessing) {
                    this.hideStatus();
                }
            }, 3000);
        }
    }

    /**
     * 更新使用统计
     */
    updateUsageStats() {
        chrome.runtime.sendMessage({
            action: 'update_usage_stats'
        });
    }

    async getVideoContext() {
        const videoId = this.getCurrentVideoId();
        const videoTitle = this.getVideoTitle();
        const currentTime = this.getCurrentTime();

        if (!videoId) {
            return null;
        }

        // 获取字幕数据
        if (!this.subtitlesData || this.currentVideoId !== videoId) {
            try {
                this.updateStatus('加载字幕...', 'processing');
                await this.loadSubtitles(videoId);
            } catch (error) {
                console.warn('字幕加载失败:', error);
                // 即使没有字幕也可以继续
            }
        }

        let relevantSubtitles = '暂无字幕';
        let fullTranscript = '暂无字幕';

        if (this.subtitlesData && this.subtitlesData.length > 0) {
            relevantSubtitles = this.subtitleExtractor.getRelevantSubtitles(
                this.subtitlesData, 
                currentTime, 
                30
            );
            fullTranscript = this.subtitleExtractor.getFullTranscript(this.subtitlesData);
        }

        return {
            videoId: videoId,
            videoTitle: videoTitle,
            currentTime: currentTime,
            relevantSubtitles: relevantSubtitles,
            fullTranscript: fullTranscript.substring(0, 4000) // 限制长度
        };
    }

    getCurrentVideoId() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('v');
    }

    getVideoTitle() {
        const titleElement = document.querySelector('h1.ytd-watch-metadata yt-formatted-string');
        return titleElement ? titleElement.textContent.trim() : 'Unknown Video';
    }

    getCurrentTime() {
        const video = document.querySelector('video');
        return video ? video.currentTime : 0;
    }

    async preloadSubtitles() {
        const videoId = this.getCurrentVideoId();
        if (videoId && videoId !== this.currentVideoId) {
            try {
                await this.loadSubtitles(videoId);
            } catch (error) {
                console.warn('预加载字幕失败:', error);
            }
        }
    }

    async loadSubtitles(videoId) {
        try {
            const subtitlesInfo = await this.subtitleExtractor.getSubtitles(videoId);
            
            if (!subtitlesInfo.subtitles || subtitlesInfo.subtitles.length === 0) {
                console.warn('没有找到字幕');
                return;
            }

            // 优先选择英文字幕
            let selectedSubtitle = subtitlesInfo.subtitles.find(sub => 
                sub.name.toLowerCase().includes('english') || sub.name.toLowerCase().includes('en')
            );

            // 如果没有英文字幕，选择第一个
            if (!selectedSubtitle) {
                selectedSubtitle = subtitlesInfo.subtitles[0];
            }

            // 下载字幕内容
            const srtContent = await this.subtitleExtractor.downloadSubtitleContent(
                selectedSubtitle.url
            );

            // 解析为时间戳数组
            this.subtitlesData = this.subtitleExtractor.parseSRTToTimestamps(srtContent);
            this.currentVideoId = videoId;

            console.log(`字幕加载成功: ${selectedSubtitle.name}, ${this.subtitlesData.length} 条记录`);

        } catch (error) {
            console.error('字幕加载失败:', error);
            throw error;
        }
    }

    observeNavigation() {
        // 监听页面导航
        let lastUrl = location.href;
        new MutationObserver(() => {
            const url = location.href;
            if (url !== lastUrl) {
                lastUrl = url;
                setTimeout(() => {
                    if (this.isVideoPage()) {
                        this.setup();
                    } else {
                        this.cleanup();
                    }
                }, 1000);
            }
        }).observe(document, { subtree: true, childList: true });
    }

    observeVideoChanges() {
        // 监听视频元素变化
        const videoContainer = document.querySelector('#player-container');
        if (videoContainer) {
            new MutationObserver(() => {
                this.preloadSubtitles();
            }).observe(videoContainer, { subtree: true, childList: true });
        }
    }

    cleanup() {
        if (this.floatingButton) {
            this.floatingButton.remove();
            this.floatingButton = null;
        }
        this.subtitlesData = null;
        this.currentVideoId = null;
        this.conversationHistory = [];
    }
}

// 初始化语音助手
let voiceAssistant = null;

function initVoiceAssistant() {
    if (!voiceAssistant) {
        voiceAssistant = new YouTubeVoiceAssistant();
    }
}

// 页面加载完成后初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initVoiceAssistant);
} else {
    initVoiceAssistant();
}

// 导出到全局
window.YouTubeVoiceAssistant = YouTubeVoiceAssistant; 